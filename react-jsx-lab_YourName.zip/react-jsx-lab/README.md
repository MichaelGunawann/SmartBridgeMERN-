# React JSX Lab

## Description
This lab demonstrates the fundamentals of building React applications using JSX syntax. It covers:
- Creating functional React components
- Using JSX to structure HTML-like output inside JavaScript
- Rendering components to the DOM with `ReactDOM.render()`
- Injecting dynamic data into JSX using JavaScript expressions (`{}`)
- Rendering lists with `.map()` and the `key` prop
- Breaking UI into reusable components (component composition)

## How to Run

1. Install dependencies:
```bash
npm install
```

2. Build the project:
```bash
npm run build
```

3. Open `public/index.html` in your browser, or use live-server:
```bash
npm install -g live-server
live-server public
```

## Project Structure
```
react-jsx-lab/
├── public/
│   └── index.html       # HTML host file
├── src/
│   ├── index.js         # Entry point — renders App to DOM
│   ├── App.js           # Main application component
│   └── Item.js          # Reusable Item component
├── .babelrc             # Babel configuration for JSX transpilation
├── package.json         # Project dependencies and build scripts
└── README.md
```

## Challenges
No major challenges were encountered. The key concept to understand is that JSX is not valid JavaScript on its own — Babel transpiles it into `React.createElement()` calls that browsers can execute. Each step in this lab builds on the last, going from a static heading all the way to a composed, dynamic component tree.
